# AI-Driven Digital Twin Platform for Real-Time Monitoring

A digital twin platform that mirrors a physical asset (e.g. an industrial machine or
IoT device) in software: a simulated sensor stream feeds a live twin model, an
anomaly-detection layer flags abnormal states, and a real-time web dashboard
visualizes the twin's telemetry via WebSockets.

> The exact wording of this bullet was cut off in the source image — this repo
> implements it as a real-time equipment-monitoring digital twin. Rename/adjust
> `src/digital_twin.py`'s fields if your real project tracked a different asset.

Run it:
```bash
pip install -r requirements.txt
python server/app.py   # then open http://localhost:5000
```

## Architecture

```
Physical asset (simulated)
        │  sensor readings (temperature, vibration, RPM, pressure)
        ▼
  DigitalTwin model  ──▶  anomaly detection (rolling z-score)
        │
        ▼
 Flask-SocketIO server ──▶ WebSocket push ──▶ browser dashboard (live charts)
```

## Project structure

```
ai-digital-twin-platform/
├── src/
│   ├── simulator.py       # generates realistic sensor telemetry
│   ├── digital_twin.py    # twin state model + rolling anomaly detection
├── server/
│   ├── app.py             # Flask-SocketIO server: runs the twin, streams state
│   └── static/
│       └── index.html     # live dashboard (Chart.js, no build step needed)
├── requirements.txt
└── README.md
```

## Quickstart

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

python server/app.py
# open http://localhost:5000 in a browser to see the live dashboard
```

## How it works

- `simulator.py` generates a continuous stream of sensor readings (temperature,
  vibration, RPM, pressure) with realistic noise and periodically injects a
  drift/spike to simulate a developing fault.
- `digital_twin.py`'s `DigitalTwin` class keeps a rolling window of recent readings
  per sensor and flags a reading as anomalous when it exceeds a z-score threshold —
  a lightweight stand-in for a trained anomaly-detection model.
- `server/app.py` runs the simulator in a background thread and pushes twin state to
  all connected browsers over WebSockets (`flask-socketio`) roughly once per second.
- `server/static/index.html` renders live line charts and an alert banner when the
  twin reports an anomaly, entirely client-side with Chart.js from a CDN.

## Extending this

- Swap `simulator.py` for a real MQTT/OPC-UA feed from actual sensors.
- Swap the z-score check in `digital_twin.py` for a trained model (isolation forest,
  autoencoder reconstruction error, etc.) for real anomaly detection.
- Persist twin history to a time-series DB (InfluxDB/TimescaleDB) instead of the
  in-memory deque, for long-term trend analysis.

## License

MIT

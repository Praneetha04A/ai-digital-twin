"""Simulates real-time sensor telemetry for a physical asset (e.g. a motor),
including an occasional injected fault so the anomaly detector has something to catch.
"""
import time
import random
import numpy as np

SENSORS = {
    "temperature_c": {"base": 65, "noise": 1.5},
    "vibration_mm_s": {"base": 2.0, "noise": 0.3},
    "rpm": {"base": 1800, "noise": 20},
    "pressure_psi": {"base": 45, "noise": 1.0},
}


class Simulator:
    def __init__(self, seed: int = 7):
        self.rng = np.random.default_rng(seed)
        self.fault_active = False
        self.fault_ticks_remaining = 0

    def _maybe_trigger_fault(self):
        if not self.fault_active and random.random() < 0.01:  # ~1% chance per tick
            self.fault_active = True
            self.fault_ticks_remaining = random.randint(15, 30)
        if self.fault_active:
            self.fault_ticks_remaining -= 1
            if self.fault_ticks_remaining <= 0:
                self.fault_active = False

    def read(self) -> dict:
        """Returns one simulated reading per sensor for this tick."""
        self._maybe_trigger_fault()
        readings = {}
        for name, cfg in SENSORS.items():
            value = self.rng.normal(cfg["base"], cfg["noise"])
            if self.fault_active:
                # simulate a developing fault: temp/vibration climb, rpm sags
                if name == "temperature_c":
                    value += 18
                elif name == "vibration_mm_s":
                    value += 4
                elif name == "rpm":
                    value -= 150
            readings[name] = round(float(value), 2)
        readings["timestamp"] = time.time()
        readings["fault_injected"] = self.fault_active
        return readings


if __name__ == "__main__":
    sim = Simulator()
    for _ in range(10):
        print(sim.read())
        time.sleep(0.5)

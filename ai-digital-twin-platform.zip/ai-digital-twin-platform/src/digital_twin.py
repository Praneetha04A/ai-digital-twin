"""The DigitalTwin keeps a live mirror of the physical asset's state and flags
anomalies using a rolling z-score per sensor (a lightweight stand-in for a
trained model -- swap in isolation forest / autoencoder reconstruction error
for production use)."""
from collections import deque
from typing import Dict, List
import numpy as np

WINDOW_SIZE = 30
Z_SCORE_THRESHOLD = 3.0


class DigitalTwin:
    def __init__(self, window_size: int = WINDOW_SIZE, z_threshold: float = Z_SCORE_THRESHOLD):
        self.window_size = window_size
        self.z_threshold = z_threshold
        self.history: Dict[str, deque] = {}
        self.latest_state: Dict = {}
        self.anomalies: List[str] = []

    def _window(self, sensor: str) -> deque:
        if sensor not in self.history:
            self.history[sensor] = deque(maxlen=self.window_size)
        return self.history[sensor]

    def update(self, reading: Dict) -> Dict:
        """Ingests one reading, updates rolling stats, and returns the twin's
        current state including any anomaly flags."""
        anomalies = []
        sensor_names = [k for k in reading if k not in ("timestamp", "fault_injected")]

        for sensor in sensor_names:
            value = reading[sensor]
            window = self._window(sensor)

            if len(window) >= 5:
                mean, std = np.mean(window), np.std(window)
                if std > 1e-6:
                    z = abs(value - mean) / std
                    if z > self.z_threshold:
                        anomalies.append({
                            "sensor": sensor,
                            "value": value,
                            "z_score": round(float(z), 2),
                            "rolling_mean": round(float(mean), 2),
                        })
            window.append(value)

        self.latest_state = {
            **reading,
            "anomalies": anomalies,
            "status": "ANOMALY" if anomalies else "NORMAL",
        }
        self.anomalies = anomalies
        return self.latest_state

    def get_state(self) -> Dict:
        return self.latest_state

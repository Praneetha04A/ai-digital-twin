"""Runs the simulator + digital twin in a background thread and streams live
state to connected browsers over WebSockets.

Usage:
    python server/app.py
    # open http://localhost:5000
"""
import sys
import time
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
from simulator import Simulator      # noqa: E402
from digital_twin import DigitalTwin  # noqa: E402

from flask import Flask, render_template
from flask_socketio import SocketIO

app = Flask(__name__, static_folder="static", template_folder="static")
socketio = SocketIO(app, cors_allowed_origins="*")

simulator = Simulator()
twin = DigitalTwin()
TICK_SECONDS = 1.0


def background_loop():
    while True:
        reading = simulator.read()
        state = twin.update(reading)
        socketio.emit("twin_update", state)
        time.sleep(TICK_SECONDS)


@app.route("/")
def index():
    return app.send_static_file("index.html")


@app.route("/state")
def state():
    return twin.get_state() or {"status": "warming up"}


@socketio.on("connect")
def on_connect():
    if twin.get_state():
        socketio.emit("twin_update", twin.get_state())


if __name__ == "__main__":
    thread = threading.Thread(target=background_loop, daemon=True)
    thread.start()
    print("Digital twin server running on http://localhost:5000")
    socketio.run(app, host="0.0.0.0", port=5000)
